document.addEventListener('DOMContentLoaded', function () {
	 
	var uName;
    var pwd;
	var eml;
	var loadHome = document.getElementById('logSub');
	// console.log(loadHome);
	// var inputs = document.querySelectorAll('input');
	// console.log(inputs);
	
	//for retrieving login info
	var myForm = document.getElementById('myForm');
	// console.log(myForm);
	
	
	//for retrieving email to newsletter
	var myOtherForm = document.getElementById('frmBox');
	console.log(myOtherForm);
	
	var pattern = 
	{
        username: /^\w{5,12}$/,
        password: /^[\w@-]{8,20}$/,
		email: /^([a-z\.\d-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,5})?$/,
    }
	
	//addEventListener when user submit the Login form
	myForm.addEventListener('submit', function () 
	{

        uName = myForm.querySelector('#uNm').value;
		console.log(uName);
		// debugger;
        pwd = myForm.querySelector('#uPsw').value;
		// console.log(pwd);

        if (validateTxtBox(uName)) 
		{
            if (validatePassword(pwd)) 
			{
                if(myForm.hasAttribute("action"))
				{
					myForm.setAttribute("action", "Home.html");
					
					alert("Bienvenue sur notre site Internet!!");
				}
            }
        }
    })
	//addEventListener when user submit email to newsletter
	myOtherForm.addEventListener('submit', function ()
	{
		// debugger;
		eml = myOtherForm.querySelector('#uEml').value;
		console.log(eml);
		if(validateEmail(eml, pattern.email))
		{
			alert("Vous êtes désormais inscrit à notre infolettre");
		}
		
		
		
	})
	
	
	
	// validation function
    function validateTxtBox(field) 
	{

        if (field === "admin") 
		{
         
			myForm.querySelector('#vUName').textContent = "";
            return true;
        } 
		else if (field === "")
		{

           
            //myForm.querySelector('#vUName').textContent = "Username must contain 5-12 characters";
			alert("Le nom d'utilisateur doit contenir 5-12 caractères");
            return false;

        }
		else
		{
			//myForm.querySelector('#vUName').textContent = "Wrong user name";
			alert("Mauvais nom d'utilisateur");
            return false;
		}
    }
	
	
	function validatePassword (field)
	{
		
        if (field === "12345") 
		{
         
			//myForm.querySelector('#vUPassw').textContent = "";
            return true;
        } 
		else if (field === "")
		{

           
            //myForm.querySelector('#vUPassw').textContent = "Password must alphanumeric, 8 - 20 characters";
			alert("Le mot de passe doit être alphanumérique et entre 8 et 20 caractères");
            return false;

        }
		else
		{
			//myForm.querySelector('#vUPassw').textContent = "Wrong password";
			alert("Mauvais mot de passe");
            return false;
		}

        
	}
	function validateEmail (field, regex)
	{
		
		if(regex.test(field))
		{
			// debugger;
			// myOtherForm.getElementById('vUEml').innerHTML = "Merci!!";
			alert("Merci!!");
			return true;
		}
		else
		{
			alert("Email must be a valid address, e.g. pepito@mydomain.com");
			return false;
		}
		
		
	}
	

})	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
