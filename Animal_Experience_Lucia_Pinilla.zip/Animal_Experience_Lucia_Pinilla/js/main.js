// document.addEventListener('DOMContentLoaded', function ()
// {
	
	var eml;
	var nbAnim;
	var qtyIndex;
	var countHeader;
	var countIndex;
	var theWrapp = document.querySelector('#wrapper');
	console.log(theWrapp);
	var qtySection = document.querySelector('#detKan');
	console.log(qtySection);
	
	//for retrieving email to newsletter
	var myOtherForm = document.getElementById('frmBox');
	console.log(myOtherForm);
	
	var pattern = 
	{
        username: /^\w{5,12}$/,
        password: /^[\w@-]{8,20}$/,
		email: /^([a-z\.\d-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,5})?$/,
		numberAnimals: /^[1-5]$/,
    }
	
	//addEventListener when user submit email to newsletter
	myOtherForm.addEventListener('submit', function ()
	{
		// debugger;
		eml = myOtherForm.querySelector('#uEml').value;
		console.log(eml);
		if(validateEmail(eml, pattern.email))
		{
			alert("Vous êtes désormais inscrit à notre infolettre");
		}
	})
	function counShopp()
	{
		countHeader = theWrapp.querySelector('#cmbShAnim').value;
		console.log(countHeader);
		countIndex = theWrapp.querySelector('#cmbShAnim');
		if(validateSelect(countHeader))
		{
			
			theWrapp.querySelector('#shoppCount').textContent = countIndex.options[countIndex.selectedIndex].text;
		}
		
	}
	
	function myFunction()
	{
		// debugger;
		nbAnim = qtySection.querySelector('#cmbShAnim').value;
		console.log(nbAnim);
		qtyIndex = qtySection.querySelector('#cmbShAnim');
		
		if(validateSelect(nbAnim))
		{
			displayBill();
			
		}
		
		
	}
	// Validate Select Boxes
    function validateSelect(params) {

        if (params === 'none') 
		{
            alert("choisissez une Quantité....");
            return false;
			
        } else 
		{
           
            return true;  
        }

    }
	
	function displayBill() {

        calculateBill();
        var data = "Mme./Ms. vous reservez en location " + qtyIndex.options[qtyIndex.selectedIndex].text +
            " animaux, le total avec taxes est: \n"  + total + " par heure.";
        alert(data);



    }
	
	 //Claculate the total of the bill per animal
    function calculateBill() {


        var subTotal = parseFloat(nbAnim).toFixed(2);
        var gst = parseFloat(subTotal * 0.05).toFixed(2);
        var qst = parseFloat(subTotal * 0.1).toFixed(2);
        var sum1 = parseFloat(subTotal) + parseFloat(gst) + parseFloat(qst);
        total = "Subtotal : " + subTotal + "\n GST : " + gst + "\n QST : " + qst + "\n Total : " + sum1.toFixed(2);

    }

	function validateEmail (field, regex)
	{
		
		if(regex.test(field))
		{
			// debugger;
			// myOtherForm.getElementById('vUEml').innerHTML = "Merci!!";
			alert("Merci!!");
			return true;
		}
		else
		{
			alert("Email must be a valid address, e.g. pepito@mydomain.com");
			return false;
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
// })